package com.wang.service;

import com.wang.pojo.User;

public interface IUserService {
	public User getUserById(int userId);
}
