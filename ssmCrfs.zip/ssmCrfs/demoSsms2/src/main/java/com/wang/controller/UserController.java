package com.wang.controller;

import com.alibaba.fastjson.JSONObject;
import com.wang.pojo.User;
import com.wang.service.IUserService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.json.JsonObject;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

@Controller
@RequestMapping("/user")
public class UserController {
    @Resource
    private IUserService userService;

    @RequestMapping("/showUser")
    @ResponseBody
    public String toIndex(HttpServletRequest request, Model model) {
        int userId = Integer.parseInt(request.getParameter("id"));
        User user = this.userService.getUserById(userId);
        model.addAttribute("user", user);
        System.out.println(user.getPassword());
        if (user.getPassword().equals("12345")) {
            return "success" + user.getPassword();
        } else {
            return "fail" + user.getPassword();
        }
    }

    @RequestMapping("/testCron")
    @ResponseBody
    public void testCron(HttpServletRequest request, HttpServletResponse response) {
        response.setHeader("Access-Control-Allow-Origin", "http://localhost:8080");
    }


    @RequestMapping("/testNginx")
    @ResponseBody
    public JSONObject testNginx(HttpServletRequest request) {
        System.out.println("nginx反向代理成功了");
        JSONObject object = new JSONObject();
        object.put("userName", "wangyuqiang");
        object.put("passWord", "121443");
        return object;
    }

    @RequestMapping("/testJsonP")
//    @ResponseBody
    public void testJsonP(HttpServletRequest request, HttpServletResponse response) throws IOException {
        JSONObject json = new JSONObject();
        System.out.println("进入接口了么");
        json.put("userName", "wangYuQiang");
        json.put("passWord", "19950914My");
        String backFunction = request.getParameter("backFunction"); //返回的函数:\
        response.getWriter().println(backFunction + "(" + json.toJSONString() + ")");
    }
}